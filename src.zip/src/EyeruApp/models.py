from typing import Iterable
from django.db import models
from django.utils.translation import gettext_lazy as _
from django.db import models
from django.db.models.signals import post_save, pre_delete
from django.db.models import Sum
from django.contrib.auth.hashers import make_password

from django.dispatch import receiver
# Create your models here.
#from django.contrib.auth.models import User 
from django.contrib.auth.models import AbstractUser
from django.contrib.auth.hashers import make_password
#import RegexValidator

from django.core.validators import RegexValidator
from django.core.validators import EmailValidator

# Create your models here.
from django.utils import timezone
phone_validator = RegexValidator(r"^(\+?\d{0,4})?\s?-?\s?(\(?\d{3}\)?)\s?-?\s?(\(?\d{3}\)?)\s?-?\s?(\(?\d{4}\)?)?$", "The phone number provided is invalid")


class User(AbstractUser):
    email = models.EmailField(blank=True,)
    USERNAME_FIELD = 'username' 
    REQUIRED_FIELDS = ['email']
    phone = models.CharField(max_length=150, blank=True,help_text="Phone ")
    address = models.CharField(max_length=150, blank=True,help_text="Phone ")
   
    
    def __str__(self):
        return f"user: {self.email}"
    



class Contact(models.Model):
    name = models.TextField( max_length=150, blank=True,help_text="Name")
    
    phone = models.TextField(max_length=150, blank=True,help_text="Phone ")
    address = models.TextField(max_length=150, blank=True,help_text="address ")
    subject = models.TextField(max_length=150, blank=True,help_text="subject")
    message = models.TextField(max_length=150, blank=True,help_text="message  ")
    email = models.TextField( blank=True,help_text="Email")
    date = models.DateTimeField(auto_now_add=True)



class SiteContent(models.Model):
    home_title = models.TextField( max_length=150, blank=True,help_text="home title")
    
    home_description= models.TextField(max_length=150, blank=True,help_text="home description ")
    about_description = models.TextField(max_length=150, blank=True,help_text="about description")
    contact_description = models.TextField(max_length=150, blank=True,help_text="contact description")
    full_stack_web_developer_description = models.TextField(max_length=150, blank=True,help_text="Full Stack& Web Developer description")
    footer_full_stack_web_developer_description = models.TextField(max_length=150, blank=True,help_text="Full Stack& Web Developer description")
    
    email = models.TextField( blank=True,help_text="Email")
    website = models.TextField( blank=True,help_text="website")
    degree = models.TextField( blank=True,help_text="Degree")
    country = models.TextField( blank=True,help_text="Country")
    date = models.DateTimeField(auto_now_add=True)
   

    

   
