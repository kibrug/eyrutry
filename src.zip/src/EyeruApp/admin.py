
from django.contrib import admin
from EyeruApp.models import *




class UserAdmin(admin.ModelAdmin):
   
   
    
    list_display = ("username", "email", "first_name", "last_name", "is_staff")
    list_filter = ("is_staff", "is_superuser", "is_active", "groups")
    search_fields = ("username", "first_name", "last_name", "email")
    ordering = ("username",)
    filter_horizontal = (
        "groups",
        "user_permissions",
    )    
    
admin.site.register(User,UserAdmin)

class ContactAdmin(admin.ModelAdmin):
    list_display = ("name", "email","phone","address", "subject", "message",)
    
    search_fields = ("name", "email","phone","address", "subject", "message",)
    ordering = ("-date",)
     
   
admin.site.register(Contact,ContactAdmin)




class SiteContentAdmin(admin.ModelAdmin):
    list_display = ("home_title", "home_description","about_description","contact_description", "full_stack_web_developer_description", "footer_full_stack_web_developer_description",
                    "email","website","degree","country",)
    
    search_fields = ("home_title", "home_description","about_description","contact_description", "full_stack_web_developer_description", "footer_full_stack_web_developer_description",
                    "email","website","degree","country",)
   
     
   
admin.site.register(SiteContent,SiteContentAdmin)
