from django.apps import AppConfig


class EyeruappConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "EyeruApp"
