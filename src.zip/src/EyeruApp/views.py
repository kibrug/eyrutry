from django.shortcuts import render,redirect
from EyeruApp.models import *



def homeView(request):
    context = {}
    sitecont = SiteContent.objects.all()[:1]
    context = {"sitecont":sitecont}

    return render (request,"index.html",context)


def loginView(request):

    return redirect("admin:index")


def contactView(request):
    context = {}
    sitecont = SiteContent.objects.all()[:1]
    
    if request.method=="POST":
        name= request.POST.get("name")
        email= request.POST.get("email")
        phone= request.POST.get("phone")
        subject = request.POST.get("subject")
        message = request.POST.get("message")
        contsave = Contact.objects.create(

            name=name,
            email=email,
            phone=phone,
            subject= subject,
            message=message
        )
        contsave.save()
        thankyou ="Thank you Contact with"
        context= {"thankyou": thankyou,"sitecont":sitecont}
        return render( request,"contact.html",context)
    else:
        context = {"sitecont":sitecont}
        return render( request,"contact.html",context)
        

    

def aboutView(request):
    context = {}
    sitecont = SiteContent.objects.all()[:1]
    context = {"sitecont":sitecont}

    return render( request,"about.html",context)
