
from django.urls import path,include



from EyeruApp.views import *
app_name="EyeruApp"
urlpatterns = [
   
path("", homeView, name="home"),
path("login/",loginView,name="login"),
path("contact/",contactView, name="contact"),
path("about/",aboutView,name="about"),
   
  
]
