from __future__ import unicode_literals

from django.apps import AppConfig

__all__ = ["KibruConfig"]


class KibruConfig(AppConfig):
   
    name = "django_kibrudashboard"
    label = "django_kibrudashboard"
    verbose_name = "Django_kibrudashboard"
